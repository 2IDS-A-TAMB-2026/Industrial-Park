import 'package:flutter/material.dart';

class AppColors {
  // CORES PRINCIPAIS
  static const Color primary = Color(0xFF4CC9F0);
  static const Color primaryDark = Color(0xFF3AB0D6);

  // MODO CLARO
  static const Color lightPrimary = Color(0xFF4CC9F0);
  static const Color lightLeftPanel = Color(0xFF38414B);
  static const Color lightRightPanel = Color(0xFFF5F7FA);
  static const Color lightText = Color(0xFF1F2937);
  static const Color lightTextSecondary = Color(0xFF6B7280);

  // MODO ESCURO
  static const Color darkLeftPanel = Color(0xFF1F2937);
  static const Color darkRightPanel = Color(0xFF111827);
  static const Color darkText = Colors.white;
  static const Color darkBg = Color(0xFF111827);

  // ALTO CONTRASTE
  static const Color hcBg = Colors.black;
  static const Color hcText = Colors.white;
  static const Color hcPrimary = Colors.yellow;
  static const Color hcSecondary = Colors.white;

  // OUTRAS
  static const Color white = Colors.white;
  static const Color black = Colors.black;

  static const Color success = Color(0xFF22C55E);
  static const Color error = Color(0xFFEF4444);
  static const Color warning = Color(0xFFF59E0B);

  static const Color grey = Color(0xFF6B7280);
  static const Color lightGrey = Color(0xFFE5E7EB);
  static const Color darkGrey = Color(0xFF374151);
  static const Color errorRed = Color(0xFFEF4444);
}