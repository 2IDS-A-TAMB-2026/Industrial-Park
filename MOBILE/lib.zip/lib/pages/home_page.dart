import 'package:flutter/material.dart';

import '../app_theme.dart';

class HomePage extends StatefulWidget {
  final AppThemeMode themeMode;
  final double fontSizeScale;

  const HomePage({
    super.key,
    required this.themeMode,
    required this.fontSizeScale,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  bool _isChatOpen = false;
  bool _isAccessibilityOpen = false;

  // ============================================================
  // CHAT
  // ============================================================

  void _toggleChat() {
    setState(() {
      _isChatOpen = !_isChatOpen;

      if (_isChatOpen) {
        _isAccessibilityOpen = false;
      }
    });
  }

  // ============================================================
  // ACESSIBILIDADE
  // ============================================================

  void _toggleAccessibility() {
    setState(() {
      _isAccessibilityOpen = !_isAccessibilityOpen;

      if (_isAccessibilityOpen) {
        _isChatOpen = false;
      }
    });
  }

  // ============================================================
  // BUILD
  // ============================================================

  @override
  Widget build(BuildContext context) {
    final bool dark =
        widget.themeMode == AppThemeMode.dark;

    return Scaffold(
      body: SafeArea(
        child: MediaQuery(
          data: MediaQuery.of(context).copyWith(
            textScaler: TextScaler.linear(
              widget.fontSizeScale,
            ),
          ),
          child: Stack(
            children: [
              // ==================================================
              // CONTEÚDO PRINCIPAL
              // ==================================================

              SingleChildScrollView(
                child: Column(
                  children: [
                    _buildNavBar(),
                    _buildHero(),
                    _buildFeatures(),
                    _buildFooter(),
                  ],
                ),
              ),

              // ==================================================
              // BOTÃO DE ACESSIBILIDADE
              // ==================================================

              Positioned(
                right: 20,
                bottom: 90,
                child: FloatingActionButton(
                  heroTag: 'accessibilityButton',
                  onPressed: _toggleAccessibility,
                  backgroundColor:
                      const Color(0xFF4CC9F0),
                  child: const Icon(
                    Icons.accessibility_new,
                    color: Colors.white,
                  ),
                ),
              ),

              // ==================================================
              // BOTÃO DE CHAT
              // ==================================================

              Positioned(
                right: 20,
                bottom: 20,
                child: FloatingActionButton(
                  heroTag: 'chatButton',
                  onPressed: _toggleChat,
                  backgroundColor:
                      const Color(0xFF4CC9F0),
                  child: Icon(
                    _isChatOpen
                        ? Icons.close
                        : Icons.chat,
                    color: Colors.white,
                  ),
                ),
              ),

              // ==================================================
              // JANELA DE CHAT
              // ==================================================

              if (_isChatOpen) _buildChat(),

              // ==================================================
              // JANELA DE ACESSIBILIDADE
              // ==================================================

              if (_isAccessibilityOpen)
                _buildAccessibility(),
            ],
          ),
        ),
      ),
    );
  }

  // ============================================================
  // NAVBAR
  // ============================================================

  Widget _buildNavBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: 40,
        vertical: 20,
      ),
      child: Row(
        children: [
          // LOGO
          Row(
            children: [
              Container(
                width: 45,
                height: 45,
                decoration: BoxDecoration(
                  color: const Color(0xFF4CC9F0),
                  borderRadius:
                      BorderRadius.circular(12),
                ),
                child: const Icon(
                  Icons.local_parking_rounded,
                  color: Colors.white,
                  size: 26,
                ),
              ),

              const SizedBox(width: 12),

              const Column(
                crossAxisAlignment:
                    CrossAxisAlignment.start,
                children: [
                  Text(
                    'INDUSTRIAL',
                    style: TextStyle(
                      fontFamily: 'Poppins',
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    'PARK',
                    style: TextStyle(
                      fontFamily: 'Poppins',
                      fontSize: 11,
                      color: Color(0xFF4CC9F0),
                      fontWeight: FontWeight.bold,
                      letterSpacing: 2,
                    ),
                  ),
                ],
              ),
            ],
          ),

          const Spacer(),

          // ENTRAR
          TextButton(
            onPressed: () {
              Navigator.pushNamed(
                context,
                '/login_page.dart',
              );
            },
            child: const Text(
              'Entrar',
            ),
          ),

          const SizedBox(width: 10),

          // CADASTRAR
          ElevatedButton(
            onPressed: () {
              Navigator.pushNamed(
                context,
                '/register',
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor:
                  const Color(0xFF4CC9F0),
              foregroundColor: Colors.white,
              padding:
                  const EdgeInsets.symmetric(
                horizontal: 22,
                vertical: 14,
              ),
            ),
            child: const Text(
              'Cadastrar',
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // HERO
  // ============================================================

  Widget _buildHero() {
    final bool dark =
        widget.themeMode == AppThemeMode.dark;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(
        horizontal: 60,
        vertical: 90,
      ),
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          Text(
            'Estacionamento\ninteligente.',
            style: TextStyle(
              fontFamily: 'Poppins',
              fontSize: 48,
              height: 1.1,
              fontWeight: FontWeight.bold,
              color: dark
                  ? Colors.white
                  : Colors.black87,
            ),
          ),

          const SizedBox(height: 20),

          Text(
            'Tecnologia para tornar o gerenciamento '
            'de estacionamentos mais simples, '
            'seguro e eficiente.',
            style: TextStyle(
              fontFamily: 'Poppins',
              fontSize: 18,
              height: 1.6,
              color: dark
                  ? Colors.white70
                  : Colors.black54,
            ),
          ),

          const SizedBox(height: 30),

          ElevatedButton(
            onPressed: () {
              Navigator.pushNamed(
                context,
                '/register',
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor:
                  const Color(0xFF4CC9F0),
              foregroundColor: Colors.white,
              padding:
                  const EdgeInsets.symmetric(
                horizontal: 28,
                vertical: 16,
              ),
            ),
            child: const Text(
              'Começar agora',
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // FUNCIONALIDADES
  // ============================================================

  Widget _buildFeatures() {
    final bool dark =
        widget.themeMode == AppThemeMode.dark;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(
        horizontal: 40,
        vertical: 60,
      ),
      child: Column(
        children: [
          Text(
            'Por que usar o Industrial Park?',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontFamily: 'Poppins',
              fontSize: 28,
              fontWeight: FontWeight.bold,
              color: dark
                  ? Colors.white
                  : Colors.black87,
            ),
          ),

          const SizedBox(height: 40),

          Wrap(
            spacing: 20,
            runSpacing: 20,
            alignment: WrapAlignment.center,
            children: [
              _featureCard(
                icon: Icons.local_parking_rounded,
                title: 'Controle de vagas',
                description:
                    'Acompanhe as vagas disponíveis '
                    'e ocupadas.',
              ),

              _featureCard(
                icon: Icons.sensors_rounded,
                title: 'Sensores',
                description:
                    'Monitore as vagas utilizando '
                    'sensores inteligentes.',
              ),

              _featureCard(
                icon: Icons.dashboard_rounded,
                title: 'Dashboard',
                description:
                    'Visualize todas as informações '
                    'do estacionamento.',
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ============================================================
  // CARD DE FUNCIONALIDADE
  // ============================================================

  Widget _featureCard({
    required IconData icon,
    required String title,
    required String description,
  }) {
    return SizedBox(
      width: 280,
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(25),
          child: Column(
            children: [
              Container(
                width: 60,
                height: 60,
                decoration: BoxDecoration(
                  color: const Color(0xFF4CC9F0)
                      .withOpacity(0.15),
                  borderRadius:
                      BorderRadius.circular(15),
                ),
                child: Icon(
                  icon,
                  color:
                      const Color(0xFF4CC9F0),
                  size: 30,
                ),
              ),

              const SizedBox(height: 20),

              Text(
                title,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 17,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 10),

              Text(
                description,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 13,
                  height: 1.5,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ============================================================
  // FOOTER
  // ============================================================

  Widget _buildFooter() {
    final bool dark =
        widget.themeMode == AppThemeMode.dark;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(35),
      color: dark
          ? const Color(0xFF111827)
          : const Color(0xFFF1F5F9),
      child: Column(
        children: [
          Text(
            'INDUSTRIAL PARK',
            style: TextStyle(
              fontFamily: 'Poppins',
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: dark
                  ? Colors.white
                  : Colors.black87,
            ),
          ),

          const SizedBox(height: 10),

          Text(
            'Sistema inteligente de gerenciamento '
            'de estacionamento.',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontFamily: 'Poppins',
              fontSize: 13,
              color: dark
                  ? Colors.white70
                  : Colors.black54,
            ),
          ),

          const SizedBox(height: 15),

          Text(
            '© 2026 Industrial Park',
            style: TextStyle(
              fontFamily: 'Poppins',
              fontSize: 11,
              color: dark
                  ? Colors.white38
                  : Colors.black45,
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // CHAT
  // ============================================================

  Widget _buildChat() {
    return Positioned(
      right: 20,
      bottom: 150,
      child: Container(
        width: 280,
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Theme.of(context)
              .scaffoldBackgroundColor,
          borderRadius:
              BorderRadius.circular(15),
          boxShadow: const [
            BoxShadow(
              blurRadius: 15,
              color: Colors.black26,
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment:
              CrossAxisAlignment.start,
          children: [
            const Text(
              'Olá! 👋',
              style: TextStyle(
                fontFamily: 'Poppins',
                fontSize: 17,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 10),

            const Text(
              'Como podemos ajudar?',
              style: TextStyle(
                fontFamily: 'Poppins',
                fontSize: 13,
              ),
            ),

            const SizedBox(height: 15),

            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {},
                child: const Text(
                  'Preciso de ajuda',
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // ACESSIBILIDADE
  // ============================================================

  Widget _buildAccessibility() {
    return Positioned(
      right: 20,
      bottom: 150,
      child: Container(
        width: 250,
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: Theme.of(context)
              .scaffoldBackgroundColor,
          borderRadius:
              BorderRadius.circular(15),
          boxShadow: const [
            BoxShadow(
              blurRadius: 15,
              color: Colors.black26,
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment:
              CrossAxisAlignment.start,
          children: [
            const Text(
              'Acessibilidade',
              style: TextStyle(
                fontFamily: 'Poppins',
                fontSize: 17,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 15),

            const Text(
              'Opções de acessibilidade',
              style: TextStyle(
                fontFamily: 'Poppins',
                fontSize: 13,
              ),
            ),

            const SizedBox(height: 15),

            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text(
                'Alto contraste',
                style: TextStyle(
                  fontSize: 13,
                ),
              ),
              value: widget.themeMode ==
                  AppThemeMode.highContrast,
              onChanged: (value) {
                // Por enquanto apenas visual.
              },
            ),
          ],
        ),
      ),
    );
  }
}