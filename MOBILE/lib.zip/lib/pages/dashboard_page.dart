import 'package:flutter/material.dart';

import 'dart:math' as math;

import '../app_theme.dart';
import '../models/dashboard_data.dart';
import '../models/vaga.dart';

class DashboardPage extends StatefulWidget {
  final AppThemeMode themeMode;
  final double fontSizeScale;
  final DashboardData? data;

  const DashboardPage({
    super.key,
    required this.themeMode,
    required this.fontSizeScale,
    this.data,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  late DashboardData _data;

  String _menuAtivo = 'dashboard';

  late TextEditingController _nomeCtrl;
  late TextEditingController _emailCtrl;
  late TextEditingController _telefoneCtrl;

  final _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();

    _data = widget.data ?? DashboardData.mock();

    _nomeCtrl = TextEditingController(
      text: _data.nomeUsuario,
    );

    _emailCtrl = TextEditingController(
      text: _data.email,
    );

    _telefoneCtrl = TextEditingController(
      text: _data.telefone,
    );
  }

  @override
  void dispose() {
    _nomeCtrl.dispose();
    _emailCtrl.dispose();
    _telefoneCtrl.dispose();

    super.dispose();
  }

  bool get _isLight =>
      widget.themeMode == AppThemeMode.light;

  bool get _isHC =>
      widget.themeMode == AppThemeMode.highContrast;

  Color get _bgTop {
    if (_isHC) return Colors.black;

    return _isLight
        ? const Color(0xFFF1F5F9)
        : const Color(0xFF0F1A35);
  }

  Color get _bgBottom {
    if (_isHC) return Colors.black;

    return _isLight
        ? const Color(0xFFE2E8F0)
        : const Color(0xFF070B16);
  }

  Color get _textColor {
    if (_isHC) return const Color(0xFFFFFF00);

    return _isLight
        ? const Color(0xFF0F172A)
        : Colors.white;
  }

  Color get _textSecColor {
    if (_isHC) return const Color(0xFFFFFF00);

    return _isLight
        ? const Color(0xFF475569)
        : const Color(0xFFA9B4D0);
  }

  Color get _accent {
    if (_isHC) return const Color(0xFFFFFF00);

    return _isLight
        ? const Color(0xFF2563EB)
        : const Color(0xFF4CC9F0);
  }

  Color get _sidebarBg {
    if (_isHC) return Colors.black;

    return _isLight
        ? Colors.white
        : const Color(0xF0121C3A);
  }

  Color get _cardBg {
    return _isHC ? Colors.black : Colors.white;
  }

  Color get _cardTextColor {
    return _isHC
        ? const Color(0xFFFFFF00)
        : const Color(0xFF0B132B);
  }

  // ============================================================
  // LOGOUT
  // ============================================================

  void _confirmarLogout(BuildContext context) {
    showDialog(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          backgroundColor: _sidebarBg,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          title: Text(
            'Deseja fazer logout?',
            style: TextStyle(
              fontFamily: 'Poppins',
              color: _textColor,
              fontWeight: FontWeight.w700,
            ),
          ),
          content: Text(
            'Você será desconectado do sistema.',
            style: TextStyle(
              fontFamily: 'Poppins',
              color: _textSecColor,
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: Text(
                'Cancelar',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  color: _textSecColor,
                ),
              ),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: _accent,
                foregroundColor:
                    _isHC ? Colors.black : Colors.white,
              ),
              onPressed: () {
                Navigator.pop(ctx);

                Navigator.of(context).popUntil(
                  (route) => route.isFirst,
                );
              },
              child: const Text(
                'Sim, sair',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  // ============================================================
  // PERFIL
  // ============================================================

  void _salvarPerfil() {
    if (!(_formKey.currentState?.validate() ?? false)) {
      return;
    }

    setState(() {
      _data = DashboardData(
        totalVagas: _data.totalVagas,
        livres: _data.livres,
        ocupadas: _data.ocupadas,
        taxaOcupacao: _data.taxaOcupacao,
        barChartLabels: _data.barChartLabels,
        barChartData: _data.barChartData,
        lineChartLabels: _data.lineChartLabels,
        lineChartData: _data.lineChartData,
        vagas: _data.vagas,
        nomeUsuario: _nomeCtrl.text.trim(),
        email: _emailCtrl.text.trim(),
        telefone: _telefoneCtrl.text.trim(),
      );
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text(
          'Perfil atualizado com sucesso!',
          style: TextStyle(fontFamily: 'Poppins'),
        ),
        backgroundColor: _accent,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  // ============================================================
  // BUILD PRINCIPAL
  // ============================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: MediaQuery(
        data: MediaQuery.of(context).copyWith(
          textScaler: TextScaler.linear(
            widget.fontSizeScale,
          ),
        ),
        child: Container(
          decoration: BoxDecoration(
            gradient: RadialGradient(
              center: Alignment.topCenter,
              radius: 1.4,
              colors: [
                _bgTop,
                _bgBottom,
              ],
            ),
          ),
          child: LayoutBuilder(
            builder: (context, constraints) {
              final bool isMobile =
                  constraints.maxWidth < 900;

              final bool isSmall =
                  constraints.maxWidth < 480;

              return Row(
                crossAxisAlignment:
                    CrossAxisAlignment.stretch,
                children: [
                  if (!isMobile)
                    _buildSidebar(context),

                  Expanded(
                    child: SingleChildScrollView(
                      padding: EdgeInsets.all(
                        isSmall
                            ? 14
                            : (isMobile ? 20 : 40),
                      ),
                      child: Column(
                        crossAxisAlignment:
                            CrossAxisAlignment.start,
                        children: [
                          if (isMobile)
                            _buildMobileTopBar(context),

                          if (_menuAtivo == 'dashboard') ...[
                            _buildPageTitle(isSmall),

                            const SizedBox(height: 24),

                            _buildIndicatorGrid(
                              constraints.maxWidth,
                            ),

                            const SizedBox(height: 24),

                            _buildChartsRow(isMobile),

                            const SizedBox(height: 24),

                            _buildParkingMapCard(
                              constraints.maxWidth,
                            ),
                          ] else
                            _buildPerfilSection(isSmall),
                        ],
                      ),
                    ),
                  ),
                ],
              );
            },
          ),
        ),
      ),

      bottomNavigationBar: MediaQuery.of(context)
                  .size
                  .width <
              900
          ? _buildMobileBottomNav()
          : null,
    );
  }

  // ============================================================
  // NAVEGAÇÃO MOBILE
  // ============================================================

  Widget _buildMobileBottomNav() {
    Widget navItem(
      IconData icon,
      String label,
      String keyName,
    ) {
      final bool isActive =
          _menuAtivo == keyName;

      return Expanded(
        child: InkWell(
          onTap: () {
            setState(() {
              _menuAtivo = keyName;
            });
          },
          child: Padding(
            padding:
                const EdgeInsets.symmetric(
              vertical: 10,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  icon,
                  size: 22,
                  color: isActive
                      ? _accent
                      : _textSecColor,
                ),
                const SizedBox(height: 4),
                Text(
                  label,
                  style: TextStyle(
                    fontFamily: 'Poppins',
                    fontSize: 11,
                    color: isActive
                        ? _accent
                        : _textSecColor,
                    fontWeight: isActive
                        ? FontWeight.w600
                        : FontWeight.normal,
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return Container(
      decoration: BoxDecoration(
        color: _sidebarBg,
        border: Border(
          top: BorderSide(
            color: _accent.withOpacity(0.15),
          ),
        ),
      ),
      child: SafeArea(
        child: Row(
          children: [
            navItem(
              Icons.house_rounded,
              'Dashboard',
              'dashboard',
            ),
            navItem(
              Icons.person_rounded,
              'Perfil',
              'perfil',
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMobileTopBar(BuildContext context) {
    return Padding(
      padding:
          const EdgeInsets.only(bottom: 20),
      child: Row(
        mainAxisAlignment:
            MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Icon(
                Icons.local_parking_rounded,
                color: _accent,
                size: 22,
              ),
              const SizedBox(width: 8),
              Text(
                'Industrial Park',
                style: TextStyle(
                  fontFamily: 'Poppins',
                  color: _accent,
                  fontWeight: FontWeight.w600,
                  fontSize: 16,
                ),
              ),
            ],
          ),
          IconButton(
            icon: Icon(
              Icons.logout_rounded,
              color: _textColor,
            ),
            onPressed: () =>
                _confirmarLogout(context),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // SIDEBAR
  // ============================================================

  Widget _buildSidebar(BuildContext context) {
    return SizedBox(
      width: 280,
      child: Container(
        padding:
            const EdgeInsets.fromLTRB(
          25,
          35,
          25,
          25,
        ),
        decoration: BoxDecoration(
          color: _sidebarBg,
          border: Border(
            right: BorderSide(
              color: _isHC
                  ? _accent
                  : _accent.withOpacity(0.1),
            ),
          ),
        ),
        child: Column(
          crossAxisAlignment:
              CrossAxisAlignment.start,
          mainAxisAlignment:
              MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(
                      Icons.local_parking_rounded,
                      color: _accent,
                      size: 22,
                    ),
                    const SizedBox(width: 10),
                    Text(
                      'Industrial Park',
                      style: TextStyle(
                        fontFamily: 'Poppins',
                        color: _accent,
                        fontWeight:
                            FontWeight.w600,
                        fontSize: 18,
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 30),

                Text(
                  _data.nomeUsuario,
                  style: TextStyle(
                    fontFamily: 'Poppins',
                    color: _textColor,
                    fontSize: 16,
                    fontWeight:
                        FontWeight.w600,
                  ),
                ),

                Text(
                  'Perfil: Usuário Comum',
                  style: TextStyle(
                    fontFamily: 'Poppins',
                    color: _textSecColor,
                    fontSize: 13,
                  ),
                ),

                const SizedBox(height: 30),

                _buildMenuItem(
                  icon: Icons.house_rounded,
                  label: 'Dashboard',
                  keyName: 'dashboard',
                ),

                _buildMenuItem(
                  icon: Icons.person_rounded,
                  label: 'Editar Perfil',
                  keyName: 'perfil',
                ),
              ],
            ),

            GestureDetector(
              onTap: () =>
                  _confirmarLogout(context),
              child: Container(
                padding:
                    const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: _accent,
                  borderRadius:
                      BorderRadius.circular(12),
                ),
                child: Row(
                  mainAxisAlignment:
                      MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.logout_rounded,
                      size: 18,
                      color: _isHC
                          ? Colors.black
                          : const Color(
                              0xFF070B16,
                            ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      'Logout',
                      style: TextStyle(
                        fontFamily: 'Poppins',
                        fontWeight:
                            FontWeight.w600,
                        color: _isHC
                            ? Colors.black
                            : const Color(
                                0xFF070B16,
                              ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMenuItem({
    required IconData icon,
    required String label,
    required String keyName,
  }) {
    final bool isActive =
        _menuAtivo == keyName;

    return Padding(
      padding:
          const EdgeInsets.only(bottom: 8),
      child: InkWell(
        borderRadius:
            BorderRadius.circular(10),
        onTap: () {
          setState(() {
            _menuAtivo = keyName;
          });
        },
        child: Container(
          padding:
              const EdgeInsets.symmetric(
            horizontal: 16,
            vertical: 14,
          ),
          decoration: BoxDecoration(
            color: isActive
                ? _accent.withOpacity(0.2)
                : Colors.transparent,
            borderRadius:
                BorderRadius.circular(10),
          ),
          child: Row(
            children: [
              Icon(
                icon,
                size: 18,
                color: isActive
                    ? _textColor
                    : _textSecColor,
              ),
              const SizedBox(width: 12),
              Text(
                label,
                style: TextStyle(
                  fontFamily: 'Poppins',
                  fontSize: 15,
                  color: isActive
                      ? _textColor
                      : _textSecColor,
                  fontWeight: isActive
                      ? FontWeight.w500
                      : FontWeight.normal,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ============================================================
  // TÍTULO
  // ============================================================

  Widget _buildPageTitle(bool isSmall) {
    return Column(
      crossAxisAlignment:
          CrossAxisAlignment.start,
      children: [
        Text(
          'Dashboard do Usuário',
          style: TextStyle(
            fontFamily: 'Poppins',
            fontSize: isSmall ? 24 : 34,
            fontWeight: FontWeight.w600,
            color: _textColor,
          ),
        ),
        const SizedBox(height: 5),
        Text(
          'Visualize informações do estacionamento e acompanhe suas atividades.',
          style: TextStyle(
            fontFamily: 'Poppins',
            fontSize: isSmall ? 13 : 15,
            color: _textSecColor,
          ),
        ),
      ],
    );
  }

  // ============================================================
  // INDICADORES
  // ============================================================

  Widget _buildIndicatorGrid(
    double maxWidth,
  ) {
    int crossAxisCount;
    double aspectRatio;

    if (maxWidth < 420) {
      crossAxisCount = 1;
      aspectRatio = 2.4;
    } else if (maxWidth < 700) {
      crossAxisCount = 2;
      aspectRatio = 1.3;
    } else if (maxWidth < 1100) {
      crossAxisCount = 2;
      aspectRatio = 1.5;
    } else {
      crossAxisCount = 4;
      aspectRatio = 1.2;
    }

    final items = [
      _IndicatorSpec(
        title: 'Total de Vagas',
        value: '${_data.totalVagas}',
        color: _cardTextColor,
        mini: 'Vagas cadastradas',
      ),
      _IndicatorSpec(
        title: 'Vagas Livres',
        value: '${_data.livres}',
        color: const Color(0xFF2ECC71),
        mini: 'Disponíveis',
      ),
      _IndicatorSpec(
        title: 'Vagas Ocupadas',
        value: '${_data.ocupadas}',
        color: const Color(0xFFE74C3C),
        mini: 'Em uso',
      ),
      _IndicatorSpec(
        title: 'Taxa de Ocupação',
        value: '${_data.taxaOcupacao}%',
        color: const Color(0xFFF39C12),
        mini: 'Percentual atual',
      ),
    ];

    return GridView.count(
      crossAxisCount: crossAxisCount,
      shrinkWrap: true,
      physics:
          const NeverScrollableScrollPhysics(),
      crossAxisSpacing: 16,
      mainAxisSpacing: 16,
      childAspectRatio: aspectRatio,
      children: items
          .map(
            (item) =>
                _buildIndicatorCard(item),
          )
          .toList(),
    );
  }

  Widget _buildIndicatorCard(
    _IndicatorSpec item,
  ) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: _cardBg,
        borderRadius:
            BorderRadius.circular(20),
        border: _isHC
            ? Border.all(
                color: _accent,
                width: 2,
              )
            : null,
        boxShadow: _isHC
            ? null
            : [
                BoxShadow(
                  color: Colors.black
                      .withOpacity(0.15),
                  blurRadius: 20,
                  offset:
                      const Offset(0, 8),
                ),
              ],
      ),
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          Text(
            item.title.toUpperCase(),
            style: TextStyle(
              fontFamily: 'Poppins',
              fontSize: 12,
              fontWeight: FontWeight.w600,
              letterSpacing: 0.6,
              color: _isHC
                  ? _accent
                  : const Color(
                      0xFF56667D,
                    ),
            ),
          ),
          Expanded(
            child: Center(
              child: Column(
                mainAxisAlignment:
                    MainAxisAlignment.center,
                children: [
                  FittedBox(
                    child: Text(
                      item.value,
                      style: TextStyle(
                        fontFamily:
                            'Poppins',
                        fontSize: 40,
                        fontWeight:
                            FontWeight.w700,
                        color: item.color,
                      ),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    item.mini,
                    style: TextStyle(
                      fontFamily: 'Poppins',
                      fontSize: 13,
                      color: _isHC
                          ? _accent
                          : const Color(
                              0xFF6B7280,
                            ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // GRÁFICOS
  // ============================================================

  Widget _buildChartsRow(
    bool isMobile,
  ) {
    final barCard = _buildChartCard(
      title: 'Entradas por Dia da Semana',
      child: _BarChart(
        labels: _data.barChartLabels,
        values: _data.barChartData,
        barColor: _accent,
        textColor: _isHC
            ? _accent
            : const Color(0xFF56667D),
      ),
    );

    final lineCard = _buildChartCard(
      title: 'Fluxo por Horários',
      child: _LineChart(
        labels: _data.lineChartLabels,
        values: _data.lineChartData,
        lineColor:
            const Color(0xFFF39C12),
        textColor: _isHC
            ? _accent
            : const Color(0xFF56667D),
      ),
    );

    if (isMobile) {
      return Column(
        children: [
          barCard,
          const SizedBox(height: 20),
          lineCard,
        ],
      );
    }

    return Row(
      crossAxisAlignment:
          CrossAxisAlignment.start,
      children: [
        Expanded(child: barCard),
        const SizedBox(width: 20),
        Expanded(child: lineCard),
      ],
    );
  }

  Widget _buildChartCard({
    required String title,
    required Widget child,
  }) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: _cardBg,
        borderRadius:
            BorderRadius.circular(20),
        border: _isHC
            ? Border.all(
                color: _accent,
                width: 2,
              )
            : null,
        boxShadow: _isHC
            ? null
            : [
                BoxShadow(
                  color: Colors.black
                      .withOpacity(0.15),
                  blurRadius: 20,
                  offset:
                      const Offset(0, 8),
                ),
              ],
      ),
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          Text(
            title.toUpperCase(),
            style: TextStyle(
              fontFamily: 'Poppins',
              fontSize: 12,
              fontWeight: FontWeight.w600,
              letterSpacing: 0.6,
              color: _isHC
                  ? _accent
                  : const Color(
                      0xFF56667D,
                    ),
            ),
          ),
          const SizedBox(height: 16),
          SizedBox(
            height: 220,
            child: child,
          ),
        ],
      ),
    );
  }

  // ============================================================
  // MAPA
  // ============================================================

  Widget _buildParkingMapCard(
    double maxWidth,
  ) {
    final Map<int, List<Vaga>> pisos = {};

    for (final vaga in _data.vagas) {
      pisos.putIfAbsent(
        vaga.piso,
        () => [],
      ).add(vaga);
    }

    final pisosOrdenados =
        pisos.keys.toList()..sort();

    final bool isMobile =
        maxWidth < 900;

    final double availableWidth =
        maxWidth -
            (isMobile ? 40 : 320) -
            48;

    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(
        maxWidth < 480 ? 16 : 24,
      ),
      decoration: BoxDecoration(
        color: _cardBg,
        borderRadius:
            BorderRadius.circular(20),
        border: _isHC
            ? Border.all(
                color: _accent,
                width: 2,
              )
            : null,
        boxShadow: _isHC
            ? null
            : [
                BoxShadow(
                  color: Colors.black
                      .withOpacity(0.15),
                  blurRadius: 20,
                  offset:
                      const Offset(0, 8),
                ),
              ],
      ),
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          Text(
            'MAPA DO ESTACIONAMENTO',
            style: TextStyle(
              fontFamily: 'Poppins',
              fontSize: 12,
              fontWeight: FontWeight.w600,
              letterSpacing: 0.6,
              color: _isHC
                  ? _accent
                  : const Color(
                      0xFF56667D,
                    ),
            ),
          ),

          const SizedBox(height: 18),

          _buildLegend(),

          const SizedBox(height: 20),

          ...pisosOrdenados.map(
            (piso) => Padding(
              padding:
                  const EdgeInsets.only(
                bottom: 30,
              ),
              child: _FloorSection(
                pisoNome: 'Piso $piso',
                vagas: pisos[piso]!,
                availableWidth:
                    availableWidth,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLegend() {
    Widget legendItem(
      Color dot,
      Color carColor,
      String label,
    ) {
      return Row(
        mainAxisSize:
            MainAxisSize.min,
        children: [
          Container(
            width: 12,
            height: 12,
            decoration: BoxDecoration(
              color: dot,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color:
                      dot.withOpacity(0.7),
                  blurRadius: 8,
                ),
              ],
            ),
          ),
          const SizedBox(width: 10),
          Icon(
            Icons.directions_car_rounded,
            color: carColor,
            size: 22,
          ),
          const SizedBox(width: 8),
          Text(
            label,
            style: TextStyle(
              fontFamily: 'Poppins',
              fontSize: 12,
              color: _textSecColor,
            ),
          ),
        ],
      );
    }

    return Container(
      padding:
          const EdgeInsets.symmetric(
        horizontal: 18,
        vertical: 14,
      ),
      decoration: BoxDecoration(
        color: const Color(0xFF1E293B),
        borderRadius:
            BorderRadius.circular(12),
        border: Border.all(
          color: const Color(0xFF334155),
        ),
      ),
      child: Wrap(
        spacing: 20,
        runSpacing: 12,
        children: [
          legendItem(
            const Color(0xFF2ECC71),
            const Color(0xFF2ECC71),
            'Vaga Livre',
          ),
          legendItem(
            const Color(0xFFE74C3C),
            const Color(0xFFE74C3C),
            'Vaga Ocupada',
          ),
          legendItem(
            const Color(0xFF7F8C8D),
            const Color(0xFF7F8C8D),
            'Vaga Indisponível',
          ),
        ],
      ),
    );
  }

  // ============================================================
  // PERFIL
  // ============================================================

  Widget _buildPerfilSection(
    bool isSmall,
  ) {
    return Column(
      crossAxisAlignment:
          CrossAxisAlignment.start,
      children: [
        Text(
          'Editar Perfil',
          style: TextStyle(
            fontFamily: 'Poppins',
            fontSize: isSmall ? 24 : 34,
            fontWeight: FontWeight.w600,
            color: _textColor,
          ),
        ),

        const SizedBox(height: 5),

        Text(
          'Atualize suas informações pessoais.',
          style: TextStyle(
            fontFamily: 'Poppins',
            fontSize: isSmall ? 13 : 15,
            color: _textSecColor,
          ),
        ),

        const SizedBox(height: 24),

        Container(
          width: double.infinity,
          constraints:
              const BoxConstraints(
            maxWidth: 560,
          ),
          padding: EdgeInsets.all(
            isSmall ? 20 : 28,
          ),
          decoration: BoxDecoration(
            color: _cardBg,
            borderRadius:
                BorderRadius.circular(20),
            border: _isHC
                ? Border.all(
                    color: _accent,
                    width: 2,
                  )
                : null,
          ),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                Center(
                  child: Container(
                    width: 84,
                    height: 84,
                    decoration:
                        BoxDecoration(
                      shape: BoxShape.circle,
                      color: _accent
                          .withOpacity(0.15),
                      border: Border.all(
                        color: _accent,
                        width: 2,
                      ),
                    ),
                    child: Icon(
                      Icons.person_rounded,
                      size: 42,
                      color: _accent,
                    ),
                  ),
                ),

                const SizedBox(height: 24),

                _buildProfileField(
                  label: 'Nome completo',
                  controller: _nomeCtrl,
                  icon: Icons.badge_rounded,
                  validator: (value) {
                    if (value == null ||
                        value.trim().isEmpty) {
                      return 'Informe seu nome';
                    }

                    return null;
                  },
                ),

                const SizedBox(height: 16),

                _buildProfileField(
                  label: 'E-mail',
                  controller: _emailCtrl,
                  icon: Icons.email_rounded,
                  keyboardType:
                      TextInputType.emailAddress,
                  validator: (value) {
                    if (value == null ||
                        value.trim().isEmpty) {
                      return 'Informe seu e-mail';
                    }

                    if (!value.contains('@') ||
                        !value.contains('.')) {
                      return 'E-mail inválido';
                    }

                    return null;
                  },
                ),

                const SizedBox(height: 16),

                _buildProfileField(
                  label: 'Telefone',
                  controller:
                      _telefoneCtrl,
                  icon: Icons.phone_rounded,
                  keyboardType:
                      TextInputType.phone,
                  validator: (value) {
                    if (value == null ||
                        value.trim().isEmpty) {
                      return 'Informe seu telefone';
                    }

                    return null;
                  },
                ),

                const SizedBox(height: 28),

                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    style:
                        ElevatedButton.styleFrom(
                      backgroundColor:
                          _accent,
                      foregroundColor:
                          _isHC
                              ? Colors.black
                              : Colors.white,
                      padding:
                          const EdgeInsets
                              .symmetric(
                        vertical: 16,
                      ),
                      shape:
                          RoundedRectangleBorder(
                        borderRadius:
                            BorderRadius.circular(
                          12,
                        ),
                      ),
                    ),
                    onPressed: _salvarPerfil,
                    child: const Text(
                      'Salvar Alterações',
                      style: TextStyle(
                        fontFamily: 'Poppins',
                        fontWeight:
                            FontWeight.w600,
                        fontSize: 15,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildProfileField({
    required String label,
    required TextEditingController controller,
    required IconData icon,
    TextInputType? keyboardType,
    String? Function(String?)? validator,
  }) {
    return TextFormField(
      controller: controller,
      keyboardType: keyboardType,
      validator: validator,
      style: TextStyle(
        fontFamily: 'Poppins',
        color: _cardTextColor,
      ),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: TextStyle(
          fontFamily: 'Poppins',
          color: _textSecColor,
        ),
        prefixIcon: Icon(
          icon,
          color: _accent,
          size: 20,
        ),
        filled: true,
        fillColor: _isHC
            ? Colors.black
            : const Color(0xFFF8FAFC),
        border: OutlineInputBorder(
          borderRadius:
              BorderRadius.circular(12),
          borderSide: BorderSide(
            color: _accent.withOpacity(0.2),
          ),
        ),
        focusedBorder:
            OutlineInputBorder(
          borderRadius:
              BorderRadius.circular(12),
          borderSide: BorderSide(
            color: _accent,
            width: 2,
          ),
        ),
      ),
    );
  }
}

// ============================================================
// INDICADORES
// ============================================================

class _IndicatorSpec {
  final String title;
  final String value;
  final Color color;
  final String mini;

  const _IndicatorSpec({
    required this.title,
    required this.value,
    required this.color,
    required this.mini,
  });
}

// ============================================================
// PISO DO ESTACIONAMENTO
// ============================================================

class _FloorSection extends StatelessWidget {
  final String pisoNome;
  final List<Vaga> vagas;
  final double availableWidth;

  const _FloorSection({
    required this.pisoNome,
    required this.vagas,
    required this.availableWidth,
  });

  @override
  Widget build(BuildContext context) {
    final metade =
        (vagas.length / 2).ceil();

    final filaSuperior =
        vagas.take(metade).toList();

    final filaInferior =
        vagas.skip(metade).toList();

    const double minSpotWidth = 78;

    final double naturalWidth =
        math.max(
      vagas.length *
              minSpotWidth +
          60,
      420,
    );

    final double mapWidth =
        availableWidth > naturalWidth
            ? availableWidth
            : naturalWidth;

    final bool needsScroll =
        availableWidth < naturalWidth;

    final content = SizedBox(
      width: mapWidth,
      child: Column(
        children: [
          _buildSpotsRow(
            filaSuperior,
            isTop: true,
          ),
          _buildDriveway(),
          _buildSpotsRow(
            filaInferior,
            isTop: false,
          ),
        ],
      ),
    );

    return Column(
      crossAxisAlignment:
          CrossAxisAlignment.start,
      children: [
        Container(
          padding:
              const EdgeInsets.symmetric(
            horizontal: 20,
            vertical: 12,
          ),
          decoration:
              const BoxDecoration(
            color: Color(0xFF0F172A),
            borderRadius:
                BorderRadius.only(
              topLeft:
                  Radius.circular(12),
              topRight:
                  Radius.circular(12),
            ),
          ),
          child: Row(
            mainAxisAlignment:
                MainAxisAlignment.spaceBetween,
            children: [
              const Row(
                children: [
                  Icon(
                    Icons.layers_rounded,
                    color: Colors.white,
                    size: 16,
                  ),
                  SizedBox(width: 8),
                  Text(
                    'SETOR DE ESTACIONAMENTO',
                    style: TextStyle(
                      fontFamily: 'Poppins',
                      color: Colors.white,
                      fontSize: 13,
                      fontWeight:
                          FontWeight.w700,
                    ),
                  ),
                ],
              ),
              Text(
                pisoNome,
                style: const TextStyle(
                  fontFamily: 'Poppins',
                  color: Color(0xFF38BDF8),
                  fontSize: 12,
                  fontWeight:
                      FontWeight.w500,
                ),
              ),
            ],
          ),
        ),

        Container(
          width: double.infinity,
          padding:
              const EdgeInsets.all(20),
          decoration: const BoxDecoration(
            color: Color(0xFF242830),
            borderRadius:
                BorderRadius.only(
              bottomLeft:
                  Radius.circular(12),
              bottomRight:
                  Radius.circular(12),
            ),
          ),
          child: needsScroll
              ? SingleChildScrollView(
                  scrollDirection:
                      Axis.horizontal,
                  child: content,
                )
              : content,
        ),
      ],
    );
  }

  Widget _buildSpotsRow(
    List<Vaga> lista, {
    required bool isTop,
  }) {
    return Row(
      children: lista
          .map(
            (vaga) => Expanded(
              child: _SpotWidget(
                vaga: vaga,
                isTop: isTop,
              ),
            ),
          )
          .toList(),
    );
  }

  Widget _buildDriveway() {
    return Container(
      height: 70,
      margin:
          const EdgeInsets.symmetric(
        vertical: 14,
      ),
      decoration: const BoxDecoration(
        color: Color(0xFF1C2026),
        border: Border(
          top: BorderSide(
            color: Color(0xFF334155),
            width: 2,
          ),
          bottom: BorderSide(
            color: Color(0xFF334155),
            width: 2,
          ),
        ),
      ),
      child: Row(
        mainAxisAlignment:
            MainAxisAlignment.spaceAround,
        children: [
          _trafficTag(
            Icons.arrow_circle_right_rounded,
            'ENTRADA',
            const Color(0xFF2ECC71),
          ),
          _trafficTag(
            Icons.arrow_right_alt_rounded,
            'SENTIDO ÚNICO',
            const Color(0xFF94A3B8),
          ),
          _trafficTag(
            Icons.arrow_circle_right_rounded,
            'SAÍDA',
            const Color(0xFFE74C3C),
          ),
        ],
      ),
    );
  }

  Widget _trafficTag(
    IconData icon,
    String label,
    Color iconColor,
  ) {
    return Container(
      padding:
          const EdgeInsets.symmetric(
        horizontal: 10,
        vertical: 5,
      ),
      decoration: BoxDecoration(
        color:
            const Color(0xFF0F172A),
        borderRadius:
            BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize:
            MainAxisSize.min,
        children: [
          Icon(
            icon,
            size: 14,
            color: iconColor,
          ),
          const SizedBox(width: 6),
          Text(
            label,
            style: const TextStyle(
              fontFamily: 'Poppins',
              fontSize: 9,
              color: Color(0xFF94A3B8),
              fontWeight:
                  FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// VAGA
// ============================================================

class _SpotWidget extends StatelessWidget {
  final Vaga vaga;
  final bool isTop;

  const _SpotWidget({
    required this.vaga,
    required this.isTop,
  });

  @override
  Widget build(BuildContext context) {
    Color statusColor;
    Color ledColor;

    switch (vaga.status) {
      case VagaStatus.livre:
        statusColor =
            const Color(0xFF2ECC71);
        ledColor = vaga.pcd
            ? const Color(0xFF3498DB)
            : const Color(0xFF2ECC71);
        break;

      case VagaStatus.ocupado:
        statusColor =
            const Color(0xFFE74C3C);
        ledColor =
            const Color(0xFFE74C3C);
        break;

      case VagaStatus.indisponivel:
        statusColor =
            const Color(0xFF7F8C8D);
        ledColor =
            const Color(0xFF7F8C8D);
        break;
    }

    String statusText;

    switch (vaga.status) {
      case VagaStatus.livre:
        statusText = 'Livre';
        break;
      case VagaStatus.ocupado:
        statusText = 'Ocupado';
        break;
      case VagaStatus.indisponivel:
        statusText = 'Indisponível';
        break;
    }

    return Container(
      height: 140,
      margin:
          const EdgeInsets.symmetric(
        horizontal: 6,
      ),
      decoration: BoxDecoration(
        color: vaga.pcd
            ? const Color(0xFF3498DB)
                .withOpacity(0.18)
            : null,
        border: Border(
          left: BorderSide(
            color: Colors.white
                .withOpacity(0.7),
            width: 3,
          ),
          right: BorderSide(
            color: Colors.white
                .withOpacity(0.7),
            width: 3,
          ),
          top: isTop
              ? const BorderSide(
                  color: Color(0xFFF1C40F),
                  width: 5,
                )
              : BorderSide.none,
          bottom: !isTop
              ? const BorderSide(
                  color: Color(0xFFF1C40F),
                  width: 5,
                )
              : BorderSide.none,
        ),
      ),
      child: Stack(
        alignment: Alignment.center,
        children: [
          if (vaga.pcd)
            Icon(
              Icons.accessible_rounded,
              size: 30,
              color: const Color(
                0xFF3498DB,
              ).withOpacity(0.35),
            ),

          Positioned(
            top: isTop ? 8 : null,
            bottom: isTop ? null : 8,
            child: Text(
              vaga.label,
              style: TextStyle(
                fontFamily: 'monospace',
                color: Colors.white
                    .withOpacity(0.5),
                fontSize: 13,
                fontWeight:
                    FontWeight.bold,
              ),
            ),
          ),

          Transform.rotate(
            angle: isTop ? math.pi : 0,
            child: Icon(
              Icons.directions_car_rounded,
              size: 46,
              color:
                  statusColor.withOpacity(
                0.95,
              ),
            ),
          ),

          Positioned(
            top: isTop ? 30 : null,
            bottom: isTop ? null : 30,
            child: Text(
              statusText,
              style: TextStyle(
                fontFamily: 'Poppins',
                fontSize: 9,
                fontWeight:
                    FontWeight.w700,
                color: statusColor,
              ),
            ),
          ),

          Positioned(
            top: isTop ? null : 6,
            bottom: isTop ? 6 : null,
            child: Container(
              width: 9,
              height: 9,
              decoration:
                  BoxDecoration(
                color: ledColor,
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: ledColor
                        .withOpacity(0.8),
                    blurRadius: 8,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// GRÁFICO DE BARRAS
// ============================================================

class _BarChart extends StatelessWidget {
  final List<String> labels;
  final List<double> values;
  final Color barColor;
  final Color textColor;

  const _BarChart({
    required this.labels,
    required this.values,
    required this.barColor,
    required this.textColor,
  });

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: _BarChartPainter(
        labels: labels,
        values: values,
        barColor: barColor,
        textColor: textColor,
      ),
      size: Size.infinite,
    );
  }
}

class _BarChartPainter
    extends CustomPainter {
  final List<String> labels;
  final List<double> values;
  final Color barColor;
  final Color textColor;

  _BarChartPainter({
    required this.labels,
    required this.values,
    required this.barColor,
    required this.textColor,
  });

  @override
  void paint(
    Canvas canvas,
    Size size,
  ) {
    if (values.isEmpty) return;

    final maxVal =
        values.reduce(math.max);

    final chartHeight =
        size.height - 30;

    final chartWidth =
        size.width;

    final barSlot =
        chartWidth / values.length;

    final barWidth =
        barSlot * 0.5;

    final gridPaint = Paint()
      ..color =
          textColor.withOpacity(0.15)
      ..strokeWidth = 1;

    for (int i = 0; i <= 4; i++) {
      final y = chartHeight -
          (chartHeight / 4) * i;

      canvas.drawLine(
        Offset(0, y),
        Offset(chartWidth, y),
        gridPaint,
      );
    }

    for (int i = 0;
        i < values.length;
        i++) {
      final barHeight = maxVal == 0
          ? 0.0
          : (values[i] / maxVal) *
              chartHeight;

      final left =
          i * barSlot +
              (barSlot - barWidth) /
                  2;

      final rect =
          Rect.fromLTWH(
        left,
        chartHeight -
            barHeight,
        barWidth,
        barHeight,
      );

      final paint = Paint()
        ..color = barColor;

      canvas.drawRRect(
        RRect.fromRectAndCorners(
          rect,
          topLeft:
              const Radius.circular(6),
          topRight:
              const Radius.circular(6),
        ),
        paint,
      );

      final tp = TextPainter(
        text: TextSpan(
          text: labels[i],
          style: TextStyle(
            fontFamily: 'Poppins',
            color: textColor,
            fontSize: 11,
          ),
        ),
        textDirection:
            TextDirection.ltr,
      )..layout();

      tp.paint(
        canvas,
        Offset(
          i * barSlot +
              (barSlot - tp.width) /
                  2,
          chartHeight + 8,
        ),
      );
    }
  }

  @override
  bool shouldRepaint(
    covariant _BarChartPainter oldDelegate,
  ) {
    return true;
  }
}

// ============================================================
// GRÁFICO DE LINHA
// ============================================================

class _LineChart extends StatelessWidget {
  final List<String> labels;
  final List<double> values;
  final Color lineColor;
  final Color textColor;

  const _LineChart({
    required this.labels,
    required this.values,
    required this.lineColor,
    required this.textColor,
  });

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: _LineChartPainter(
        labels: labels,
        values: values,
        lineColor: lineColor,
        textColor: textColor,
      ),
      size: Size.infinite,
    );
  }
}

class _LineChartPainter
    extends CustomPainter {
  final List<String> labels;
  final List<double> values;
  final Color lineColor;
  final Color textColor;

  _LineChartPainter({
    required this.labels,
    required this.values,
    required this.lineColor,
    required this.textColor,
  });

  @override
  void paint(
    Canvas canvas,
    Size size,
  ) {
    if (values.isEmpty) return;

    final maxVal =
        values.reduce(math.max);

    final chartHeight =
        size.height - 30;

    final chartWidth =
        size.width;

    final stepX =
        values.length > 1
            ? chartWidth /
                (values.length - 1)
            : 0.0;

    final gridPaint = Paint()
      ..color =
          textColor.withOpacity(0.15)
      ..strokeWidth = 1;

    for (int i = 0; i <= 4; i++) {
      final y = chartHeight -
          (chartHeight / 4) * i;

      canvas.drawLine(
        Offset(0, y),
        Offset(chartWidth, y),
        gridPaint,
      );
    }

    final points = <Offset>[];

    for (int i = 0;
        i < values.length;
        i++) {
      final x = i * stepX;

      final y = maxVal == 0
          ? chartHeight
          : chartHeight -
              (values[i] / maxVal) *
                  chartHeight;

      points.add(
        Offset(x, y),
      );
    }

    final linePaint = Paint()
      ..color = lineColor
      ..strokeWidth = 3
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    final path = Path()
      ..moveTo(
        points.first.dx,
        points.first.dy,
      );

    for (int i = 1;
        i < points.length;
        i++) {
      path.lineTo(
        points[i].dx,
        points[i].dy,
      );
    }

    canvas.drawPath(
      path,
      linePaint,
    );

    for (final point in points) {
      canvas.drawCircle(
        point,
        4,
        Paint()..color = lineColor,
      );
    }

    for (int i = 0;
        i < labels.length;
        i++) {
      final tp = TextPainter(
        text: TextSpan(
          text: labels[i],
          style: TextStyle(
            fontFamily: 'Poppins',
            color: textColor,
            fontSize: 10,
          ),
        ),
        textDirection:
            TextDirection.ltr,
      )..layout();

      final x =
          (i * stepX) -
              tp.width / 2;

      tp.paint(
        canvas,
        Offset(
          x.clamp(
            0.0,
            size.width - tp.width,
          ),
          chartHeight + 8,
        ),
      );
    }
  }

  @override
  bool shouldRepaint(
    covariant _LineChartPainter oldDelegate,
  ) {
    return true;
  }
}