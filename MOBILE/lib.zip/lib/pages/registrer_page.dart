import 'package:flutter/material.dart';

import '../main.dart';
import '../models/dashboard_data.dart';
import 'dashboard_page.dart';
import '../app_theme.dart';
import '../app_colors.dart';

class RegisterPage extends StatefulWidget {
  final AppThemeMode themeMode;
  final double fontSizeScale;

  const RegisterPage({
    super.key,
    required this.themeMode,
    required this.fontSizeScale,
  });

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  final _nomeController = TextEditingController();
  final _emailController = TextEditingController();
  final _senhaController = TextEditingController();
  final _confirmarSenhaController = TextEditingController();

  String? _erroNome;
  String? _erroEmail;
  String? _erroSenha;
  String? _erroConfirmarSenha;

  bool _aceitouTermos = false;
  String? _erroTermos;

  void _cadastrarUsuario() {
    setState(() {
      _erroNome = null;
      _erroEmail = null;
      _erroSenha = null;
      _erroConfirmarSenha = null;
      _erroTermos = null;
    });

    bool valido = true;

    final nome = _nomeController.text.trim();
    final email = _emailController.text.trim();
    final senha = _senhaController.text.trim();
    final confirmarSenha =
        _confirmarSenhaController.text.trim();

    // Nome
    if (nome.isEmpty) {
      _erroNome = "Digite seu nome completo";
      valido = false;
    }

    // E-mail
    if (email.isEmpty) {
      _erroEmail = "Digite seu e-mail";
      valido = false;
    } else if (!email.contains('@') || !email.contains('.')) {
      _erroEmail = "Digite um e-mail válido";
      valido = false;
    }

    // Senha
    if (senha.isEmpty) {
      _erroSenha = "Crie uma senha";
      valido = false;
    } else if (senha.length < 6) {
      _erroSenha = "Mínimo 6 caracteres";
      valido = false;
    }

    // Confirmação da senha
    if (confirmarSenha.isEmpty) {
      _erroConfirmarSenha = "Confirme sua senha";
      valido = false;
    } else if (confirmarSenha != senha) {
      _erroConfirmarSenha = "As senhas não coincidem";
      valido = false;
    }

    // Termos
    if (!_aceitouTermos) {
      _erroTermos = "Você deve aceitar os termos de uso";
      valido = false;
    }

    // Cadastro válido
    if (valido) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            "Conta criada com sucesso! Redirecionando...",
            style: TextStyle(
              fontFamily: 'Poppins',
            ),
          ),
          backgroundColor: Color(0xFF10B981),
          behavior: SnackBarBehavior.floating,
        ),
      );

      Future.delayed(const Duration(seconds: 2), () {
        if (!mounted) return;

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => DashboardPage(
              themeMode: widget.themeMode,
              fontSizeScale: widget.fontSizeScale,
              data: DashboardData.mock(),
            ),
          ),
        );
      });
    } else {
      setState(() {});
    }
  }

  @override
  void dispose() {
    _nomeController.dispose();
    _emailController.dispose();
    _senhaController.dispose();
    _confirmarSenhaController.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bool isHighContrast =
        widget.themeMode == AppThemeMode.highContrast;

    final bool isLight =
        widget.themeMode == AppThemeMode.light;

    final Color leftBg = isHighContrast
        ? AppColors.hcBg
        : (isLight
            ? AppColors.lightLeftPanel
            : AppColors.darkLeftPanel);

    final Color rightBg = isHighContrast
        ? AppColors.hcBg
        : (isLight
            ? AppColors.lightRightPanel
            : AppColors.darkRightPanel);

    final Color leftTextColor = isHighContrast
        ? AppColors.hcText
        : (isLight
            ? AppColors.lightText
            : AppColors.darkText);

    final Color rightTextColor = isHighContrast
        ? AppColors.hcText
        : AppColors.lightText;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back_rounded,
            color: isHighContrast
                ? AppColors.hcText
                : (isLight
                    ? AppColors.lightText
                    : AppColors.darkText),
          ),
          onPressed: () => Navigator.pop(context),
        ),
      ),

      body: SafeArea(
        child: MediaQuery(
          data: MediaQuery.of(context).copyWith(
            textScaler: TextScaler.linear(
              widget.fontSizeScale,
            ),
          ),
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),

              child: Container(
                constraints: const BoxConstraints(
                  maxWidth: 960,
                ),

                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(24),

                  border: isHighContrast
                      ? Border.all(
                          color: AppColors.hcPrimary,
                          width: 2,
                        )
                      : Border.all(
                          color: isLight
                              ? Colors.black.withOpacity(0.06)
                              : Colors.white10,
                        ),

                  boxShadow: isHighContrast
                      ? null
                      : [
                          BoxShadow(
                            color: isLight
                                ? Colors.black.withOpacity(0.08)
                                : Colors.black.withOpacity(0.25),
                            blurRadius: 35,
                            offset: const Offset(0, 15),
                          ),
                        ],
                ),

                child: ClipRRect(
                  borderRadius: BorderRadius.circular(24),

                  child: LayoutBuilder(
                    builder: (context, constraints) {
                      final bool isMobile =
                          constraints.maxWidth < 700;

                      return Flex(
                        direction: isMobile
                            ? Axis.vertical
                            : Axis.horizontal,

                        mainAxisSize: MainAxisSize.min,

                        children: [
                          // =========================
                          // LADO ESQUERDO
                          // =========================
                          Flexible(
                            fit: isMobile
                                ? FlexFit.loose
                                : FlexFit.tight,

                            child: Container(
                              color: leftBg,

                              padding: const EdgeInsets.all(40),

                              child: Column(
                                mainAxisAlignment:
                                    MainAxisAlignment.center,

                                children: [
                                  AppLogo(
                                    themeMode:
                                        widget.themeMode,
                                    size: 18,
                                  ),

                                  const SizedBox(height: 28),

                                  Text(
                                    'Junte-se ao Industrial Park',
                                    style: TextStyle(
                                      fontFamily: 'Poppins',
                                      fontSize: 24,
                                      fontWeight:
                                          FontWeight.w700,
                                      color: leftTextColor,
                                    ),
                                    textAlign: TextAlign.center,
                                  ),

                                  const SizedBox(height: 10),

                                  Text(
                                    'Crie sua conta corporativa para monitorar seus pátios logísticos em tempo real.',
                                    style: TextStyle(
                                      fontFamily: 'Poppins',
                                      fontSize: 14,
                                      height: 1.5,
                                      color: leftTextColor
                                          .withOpacity(0.75),
                                    ),
                                    textAlign: TextAlign.center,
                                  ),

                                  const SizedBox(height: 36),

                                  Text(
                                    'Já tem uma conta?',
                                    style: TextStyle(
                                      fontFamily: 'Poppins',
                                      fontSize: 13,
                                      fontWeight:
                                          FontWeight.w500,
                                      color: leftTextColor,
                                    ),
                                    textAlign: TextAlign.center,
                                  ),

                                  const SizedBox(height: 14),

                                  ElevatedButton(
                                    style: ElevatedButton.styleFrom(
                                      padding:
                                          const EdgeInsets.symmetric(
                                        horizontal: 32,
                                        vertical: 14,
                                      ),

                                      elevation:
                                          isLight ? 2 : 0,

                                      shape:
                                          RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(
                                          30,
                                        ),
                                      ),

                                      backgroundColor:
                                          isHighContrast
                                              ? AppColors.hcPrimary
                                              : AppColors.lightPrimary,

                                      foregroundColor:
                                          isHighContrast
                                              ? Colors.black
                                              : Colors.white,
                                    ),

                                    onPressed: () {
                                      Navigator.pop(context);
                                    },

                                    child: const Text(
                                      'Fazer Login',
                                      style: TextStyle(
                                        fontFamily: 'Poppins',
                                        fontWeight:
                                            FontWeight.w600,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),

                          // =========================
                          // LADO DIREITO
                          // =========================
                          Flexible(
                            fit: isMobile
                                ? FlexFit.loose
                                : FlexFit.tight,

                            child: Container(
                              color: rightBg,

                              padding: const EdgeInsets.all(36),

                              child: Column(
                                mainAxisAlignment:
                                    MainAxisAlignment.center,

                                children: [
                                  Text(
                                    'Criar nova conta',
                                    style: TextStyle(
                                      fontFamily: 'Poppins',
                                      fontSize: 22,
                                      fontWeight:
                                          FontWeight.w700,
                                      color: rightTextColor,
                                    ),
                                  ),

                                  const SizedBox(height: 20),

                                  // Nome
                                  _buildInputField(
                                    controller:
                                        _nomeController,
                                    hintText:
                                        'Nome completo',
                                    icon: Icons
                                        .person_outline_rounded,
                                    obscureText: false,
                                    isHighContrast:
                                        isHighContrast,
                                    isLight: isLight,
                                  ),

                                  _buildErrorText(
                                    _erroNome,
                                  ),

                                  const SizedBox(height: 6),

                                  // E-mail
                                  _buildInputField(
                                    controller:
                                        _emailController,
                                    hintText:
                                        'Seu e-mail corporativo',
                                    icon: Icons
                                        .email_outlined,
                                    obscureText: false,
                                    isHighContrast:
                                        isHighContrast,
                                    isLight: isLight,
                                  ),

                                  _buildErrorText(
                                    _erroEmail,
                                  ),

                                  const SizedBox(height: 6),

                                  // Senha
                                  _buildInputField(
                                    controller:
                                        _senhaController,
                                    hintText:
                                        'Crie uma senha',
                                    icon: Icons
                                        .lock_outline_rounded,
                                    obscureText: true,
                                    isHighContrast:
                                        isHighContrast,
                                    isLight: isLight,
                                  ),

                                  _buildErrorText(
                                    _erroSenha,
                                  ),

                                  const SizedBox(height: 6),

                                  // Confirmar senha
                                  _buildInputField(
                                    controller:
                                        _confirmarSenhaController,
                                    hintText:
                                        'Confirme a senha',
                                    icon: Icons
                                        .lock_reset_rounded,
                                    obscureText: true,
                                    isHighContrast:
                                        isHighContrast,
                                    isLight: isLight,
                                  ),

                                  _buildErrorText(
                                    _erroConfirmarSenha,
                                  ),

                                  const SizedBox(height: 10),

                                  // Termos
                                  Row(
                                    children: [
                                      SizedBox(
                                        height: 24,
                                        width: 24,

                                        child: Checkbox(
                                          value:
                                              _aceitouTermos,

                                          activeColor:
                                              isHighContrast
                                                  ? AppColors
                                                      .hcPrimary
                                                  : AppColors
                                                      .lightPrimary,

                                          onChanged: (value) {
                                            setState(() {
                                              _aceitouTermos =
                                                  value ?? false;
                                              _erroTermos = null;
                                            });
                                          },
                                        ),
                                      ),

                                      const SizedBox(width: 8),

                                      Expanded(
                                        child: Text(
                                          'Aceito os Termos de Uso e Política de Privacidade.',

                                          style: TextStyle(
                                            fontFamily:
                                                'Poppins',
                                            fontSize: 12,
                                            color: rightTextColor
                                                .withOpacity(0.8),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),

                                  _buildErrorText(
                                    _erroTermos,
                                  ),

                                  const SizedBox(height: 18),

                                  // Botão cadastrar
                                  SizedBox(
                                    width: double.infinity,

                                    child: ElevatedButton(
                                      style:
                                          ElevatedButton.styleFrom(
                                        backgroundColor:
                                            isHighContrast
                                                ? AppColors
                                                    .hcPrimary
                                                : (isLight
                                                    ? AppColors
                                                        .lightPrimary
                                                    : AppColors
                                                        .darkBg),

                                        foregroundColor:
                                            isHighContrast
                                                ? Colors.black
                                                : Colors.white,

                                        padding:
                                            const EdgeInsets
                                                .symmetric(
                                          vertical: 16,
                                        ),

                                        elevation: 4,

                                        shape:
                                            RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(
                                            16,
                                          ),
                                        ),
                                      ),

                                      onPressed:
                                          _cadastrarUsuario,

                                      child: const Text(
                                        'Cadastrar',
                                        style: TextStyle(
                                          fontFamily: 'Poppins',
                                          fontWeight:
                                              FontWeight.w600,
                                          fontSize: 15,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      );
                    },
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildInputField({
    required TextEditingController controller,
    required String hintText,
    required IconData icon,
    required bool obscureText,
    required bool isHighContrast,
    required bool isLight,
  }) {
    return TextField(
      controller: controller,

      obscureText: obscureText,

      style: TextStyle(
        fontFamily: 'Poppins',
        color: isHighContrast
            ? AppColors.hcText
            : AppColors.lightText,
      ),

      decoration: InputDecoration(
        prefixIcon: Icon(
          icon,

          color: isHighContrast
              ? AppColors.hcPrimary
              : (isLight
                  ? AppColors.lightPrimary
                  : AppColors.lightTextSecondary),

          size: 20,
        ),

        hintText: hintText,

        hintStyle: TextStyle(
          fontFamily: 'Poppins',

          color: isHighContrast
              ? AppColors.hcText.withOpacity(0.7)
              : AppColors.lightTextSecondary
                  .withOpacity(0.6),

          fontSize: 13,
        ),

        filled: true,

        fillColor:
            isHighContrast ? Colors.black : Colors.white,

        contentPadding:
            const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 14,
        ),

        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),

          borderSide: isHighContrast
              ? const BorderSide(
                  color: AppColors.hcPrimary,
                  width: 2,
                )
              : BorderSide.none,
        ),

        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),

          borderSide: isHighContrast
              ? const BorderSide(
                  color: AppColors.hcPrimary,
                  width: 2,
                )
              : BorderSide(
                  color: Colors.black.withOpacity(0.06),
                ),
        ),

        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),

          borderSide: BorderSide(
            color: isHighContrast
                ? AppColors.hcPrimary
                : AppColors.lightPrimary,
            width: 2,
          ),
        ),
      ),
    );
  }

  Widget _buildErrorText(String? error) {
    return Container(
      alignment: Alignment.centerLeft,

      padding: const EdgeInsets.only(
        top: 2,
        left: 6,
      ),

      height: 20,

      child: error != null
          ? Text(
              error,
              style: const TextStyle(
                fontFamily: 'Poppins',
                color: AppColors.errorRed,
                fontSize: 11,
                fontWeight: FontWeight.w500,
              ),
            )
          : const SizedBox.shrink(),
    );
  }
}
class AppLogo extends StatelessWidget {
  final AppThemeMode themeMode;
  final double size;

  const AppLogo({
    super.key,
    required this.themeMode,
    this.size = 24,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(
          Icons.local_parking_rounded,
          size: size,
          color: themeMode == AppThemeMode.highContrast
              ? AppColors.hcPrimary
              : AppColors.primary,
        ),

        const SizedBox(width: 8),

        Text(
          'INDUSTRIAL PARK',
          style: TextStyle(
            fontFamily: 'Poppins',
            fontSize: size * 0.7,
            fontWeight: FontWeight.bold,
            color: themeMode == AppThemeMode.dark
                ? Colors.white
                : Colors.black87,
          ),
        ),
      ],
    );
  }
}