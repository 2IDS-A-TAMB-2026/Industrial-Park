
import 'package:flutter/material.dart';

import '../main.dart';
import '../models/dashboard_data.dart';
import 'dashboard_page.dart';
import 'registrer_page.dart';
import '../app_theme.dart';
import '../app_colors.dart';

class LoginPage extends StatefulWidget {
  final AppThemeMode themeMode;
  final double fontSizeScale;

  const LoginPage({
    super.key,
    required this.themeMode,
    required this.fontSizeScale,
  });

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _emailController = TextEditingController();
  final _senhaController = TextEditingController();

  String? _erroEmail;
  String? _erroSenha;


  void _validarEAutenticar() {
    setState(() {
      _erroEmail = null;
      _erroSenha = null;
    });

    final email = _emailController.text.trim();
    final senha = _senhaController.text.trim();

    bool valido = true;

    // Verifica se o e-mail foi preenchido
    if (email.isEmpty) {
      _erroEmail = "Digite o e-mail";
      valido = false;
    }

    // Verifica se a senha foi preenchida
    if (senha.isEmpty) {
      _erroSenha = "Digite a senha";
      valido = false;
    }

    // Se os campos estiverem preenchidos,
    // verifica os dados fictícios
    if (valido) {
      if (email != "usuario@email.com") {
        _erroEmail = "E-mail incorreto";
        valido = false;
      }

      if (senha != "123456") {
        _erroSenha = "Senha incorreta";
        valido = false;
      }
    }

    // Se estiver tudo correto, entra no dashboard
    if (valido) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            "Login realizado com sucesso!",
            style: TextStyle(
              fontFamily: 'Poppins',
            ),
          ),
          backgroundColor: Color(0xFF10B981),
          behavior: SnackBarBehavior.floating,
        ),
      );

      Future.delayed(const Duration(milliseconds: 900), () {
        if (!mounted) return;

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => DashboardPage(
              themeMode: widget.themeMode,
              fontSizeScale: widget.fontSizeScale,
              data: DashboardData.mock(),
            ),
          ),
        );
      });
    } else {
      // Atualiza a tela para mostrar os erros
      setState(() {});
    }
  }


  void _irParaCadastro() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => RegisterPage(
          themeMode: widget.themeMode,
          fontSizeScale: widget.fontSizeScale,
        ),
      ),
    );
  }

  @override
  void dispose() {
    _emailController.dispose();
    _senhaController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bool isHighContrast =
        widget.themeMode == AppThemeMode.highContrast;

    final bool isLight =
        widget.themeMode == AppThemeMode.light;

    Color leftBg = isHighContrast
        ? AppColors.hcBg
        : (isLight
            ? AppColors.lightLeftPanel
            : AppColors.darkLeftPanel);

    Color rightBg = isHighContrast
        ? AppColors.hcBg
        : (isLight
            ? AppColors.lightRightPanel
            : AppColors.darkRightPanel);

    Color leftTextColor = isHighContrast
        ? AppColors.hcText
        : (isLight
            ? AppColors.lightText
            : AppColors.darkText);

    Color rightTextColor = isHighContrast
        ? AppColors.hcText
        : AppColors.lightText;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back_rounded,
            color: isHighContrast
                ? AppColors.hcText
                : (isLight
                    ? AppColors.lightText
                    : AppColors.darkText),
          ),
          onPressed: () => Navigator.pop(context),
        ),
      ),

      body: SafeArea(
        child: MediaQuery(
          data: MediaQuery.of(context).copyWith(
            textScaler: TextScaler.linear(
              widget.fontSizeScale,
            ),
          ),
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),

              child: Container(
                constraints: const BoxConstraints(
                  maxWidth: 920,
                ),

                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(24),

                  border: isHighContrast
                      ? Border.all(
                          color: AppColors.hcPrimary,
                          width: 2,
                        )
                      : Border.all(
                          color: isLight
                              ? Colors.black.withOpacity(0.06)
                              : Colors.white10,
                        ),

                  boxShadow: isHighContrast
                      ? null
                      : [
                          BoxShadow(
                            color: isLight
                                ? Colors.black.withOpacity(0.08)
                                : Colors.black.withOpacity(0.25),
                            blurRadius: 35,
                            offset: const Offset(0, 15),
                          ),
                        ],
                ),

                child: ClipRRect(
                  borderRadius: BorderRadius.circular(24),

                  child: LayoutBuilder(
                    builder: (context, constraints) {
                      final bool isMobile =
                          constraints.maxWidth < 700;

                      return Flex(
                        direction: isMobile
                            ? Axis.vertical
                            : Axis.horizontal,

                        mainAxisSize: MainAxisSize.min,

                        children: [
                          // =========================
                          // LADO ESQUERDO
                          // =========================
                          Flexible(
                            fit: isMobile
                                ? FlexFit.loose
                                : FlexFit.tight,

                            child: Container(
                              color: leftBg,

                              padding: const EdgeInsets.all(40),

                              child: Column(
                                mainAxisAlignment:
                                    MainAxisAlignment.center,

                                children: [
                                  AppLogo(
                                    themeMode:
                                        widget.themeMode,
                                    size: 18,
                                  ),

                                  const SizedBox(height: 28),

                                  Text(
                                    'Bem-vindo de volta!',
                                    style: TextStyle(
                                      fontFamily: 'Poppins',
                                      fontSize: 26,
                                      fontWeight:
                                          FontWeight.w700,
                                      color: leftTextColor,
                                    ),
                                    textAlign: TextAlign.center,
                                  ),

                                  const SizedBox(height: 10),

                                  Text(
                                    'Gerencie seu estacionamento com inteligência e praticidade.',
                                    style: TextStyle(
                                      fontFamily: 'Poppins',
                                      fontSize: 14,
                                      height: 1.5,
                                      color: leftTextColor
                                          .withOpacity(0.75),
                                    ),
                                    textAlign: TextAlign.center,
                                  ),

                                  const SizedBox(height: 36),

                                  Text(
                                    'Ainda não possui uma conta?',
                                    style: TextStyle(
                                      fontFamily: 'Poppins',
                                      fontSize: 13,
                                      fontWeight:
                                          FontWeight.w500,
                                      color: leftTextColor,
                                    ),
                                    textAlign: TextAlign.center,
                                  ),

                                  const SizedBox(height: 14),

                                  ElevatedButton(
                                    style: ElevatedButton.styleFrom(
                                      padding:
                                          const EdgeInsets.symmetric(
                                        horizontal: 32,
                                        vertical: 14,
                                      ),

                                      elevation:
                                          isLight ? 2 : 0,

                                      shape:
                                          RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(
                                          30,
                                        ),
                                      ),

                                      backgroundColor:
                                          isHighContrast
                                              ? AppColors.hcPrimary
                                              : AppColors.lightPrimary,

                                      foregroundColor:
                                          isHighContrast
                                              ? Colors.black
                                              : Colors.white,
                                    ),

                                    onPressed: _irParaCadastro,

                                    child: const Text(
                                      'Criar conta',
                                      style: TextStyle(
                                        fontFamily: 'Poppins',
                                        fontWeight:
                                            FontWeight.w600,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),

                          // =========================
                          // LADO DIREITO
                          // =========================
                          Flexible(
                            fit: isMobile
                                ? FlexFit.loose
                                : FlexFit.tight,

                            child: Container(
                              color: rightBg,

                              padding: const EdgeInsets.all(40),

                              child: Column(
                                mainAxisAlignment:
                                    MainAxisAlignment.center,

                                children: [
                                  Text(
                                    'Faça seu login',
                                    style: TextStyle(
                                      fontFamily: 'Poppins',
                                      fontSize: 24,
                                      fontWeight:
                                          FontWeight.w700,
                                      color: rightTextColor,
                                    ),
                                  ),

                                  const SizedBox(height: 28),

                                  // E-mail
                                  _buildInputField(
                                    controller:
                                        _emailController,
                                    hintText:
                                        'Digite seu e-mail',
                                    icon: Icons
                                        .email_outlined,
                                    obscureText: false,
                                    isHighContrast:
                                        isHighContrast,
                                    isLight: isLight,
                                  ),

                                  _buildErrorText(
                                    _erroEmail,
                                  ),

                                  const SizedBox(height: 8),

                                  // Senha
                                  _buildInputField(
                                    controller:
                                        _senhaController,
                                    hintText:
                                        'Digite sua senha',
                                    icon: Icons
                                        .lock_outline_rounded,
                                    obscureText: true,
                                    isHighContrast:
                                        isHighContrast,
                                    isLight: isLight,
                                  ),

                                  _buildErrorText(
                                    _erroSenha,
                                  ),

                                  const SizedBox(height: 24),

                                  SizedBox(
                                    width: double.infinity,

                                    child: ElevatedButton(
                                      style:
                                          ElevatedButton.styleFrom(
                                        backgroundColor:
                                            isHighContrast
                                                ? AppColors
                                                    .hcPrimary
                                                : (isLight
                                                    ? AppColors
                                                        .lightPrimary
                                                    : AppColors
                                                        .darkBg),

                                        foregroundColor:
                                            isHighContrast
                                                ? Colors.black
                                                : Colors.white,

                                        padding:
                                            const EdgeInsets
                                                .symmetric(
                                          vertical: 16,
                                        ),

                                        elevation: 4,

                                        shadowColor: isLight
                                            ? AppColors
                                                .lightPrimary
                                                .withOpacity(0.3)
                                            : Colors.black26,

                                        shape:
                                            RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(
                                            16,
                                          ),
                                        ),
                                      ),

                                      onPressed:
                                          _validarEAutenticar,

                                      child: const Text(
                                        'Entrar',
                                        style: TextStyle(
                                          fontFamily: 'Poppins',
                                          fontWeight:
                                              FontWeight.w600,
                                          fontSize: 15,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      );
                    },
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildInputField({
    required TextEditingController controller,
    required String hintText,
    required IconData icon,
    required bool obscureText,
    required bool isHighContrast,
    required bool isLight,
  }) {
    return TextField(
      controller: controller,

      obscureText: obscureText,

      style: TextStyle(
        fontFamily: 'Poppins',
        color: isHighContrast
            ? AppColors.hcText
            : AppColors.lightText,
      ),

      decoration: InputDecoration(
        prefixIcon: Icon(
          icon,

          color: isHighContrast
              ? AppColors.hcPrimary
              : (isLight
                  ? AppColors.lightPrimary
                  : AppColors.lightTextSecondary),

          size: 20,
        ),

        hintText: hintText,

        hintStyle: TextStyle(
          fontFamily: 'Poppins',

          color: isHighContrast
              ? AppColors.hcText.withOpacity(0.7)
              : AppColors.lightTextSecondary
                  .withOpacity(0.6),

          fontSize: 14,
        ),

        filled: true,

        fillColor:
            isHighContrast ? Colors.black : Colors.white,

        contentPadding:
            const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 16,
        ),

        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),

          borderSide: isHighContrast
              ? const BorderSide(
                  color: AppColors.hcPrimary,
                  width: 2,
                )
              : BorderSide.none,
        ),

        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),

          borderSide: isHighContrast
              ? const BorderSide(
                  color: AppColors.hcPrimary,
                  width: 2,
                )
              : BorderSide(
                  color: Colors.black.withOpacity(0.06),
                ),
        ),

        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),

          borderSide: BorderSide(
            color: isHighContrast
                ? AppColors.hcPrimary
                : AppColors.lightPrimary,
            width: 2,
          ),
        ),
      ),
    );
  }

  Widget _buildErrorText(String? error) {
    return Container(
      alignment: Alignment.centerLeft,

      padding: const EdgeInsets.only(
        top: 4,
        left: 6,
      ),

      height: 22,

      child: error != null
          ? Text(
              error,
              style: const TextStyle(
                fontFamily: 'Poppins',
                color: AppColors.errorRed,
                fontSize: 12,
                fontWeight: FontWeight.w500,
              ),
            )
          : const SizedBox.shrink(),
    );
  }
}
