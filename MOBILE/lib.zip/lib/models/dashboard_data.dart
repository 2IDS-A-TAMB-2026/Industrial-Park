import 'vaga.dart';

class DashboardData {
  final int totalVagas;
  final int livres;
  final int ocupadas;
  final double taxaOcupacao;

  final List<String> barChartLabels;
  final List<double> barChartData;

  final List<String> lineChartLabels;
  final List<double> lineChartData;

  final List<Vaga> vagas;

  final String nomeUsuario;
  final String email;
  final String telefone;

  const DashboardData({
    required this.totalVagas,
    required this.livres,
    required this.ocupadas,
    required this.taxaOcupacao,
    required this.barChartLabels,
    required this.barChartData,
    required this.lineChartLabels,
    required this.lineChartData,
    required this.vagas,
    this.nomeUsuario = 'Usuário',
    this.email = 'usuario@email.com',
    this.telefone = '(00) 00000-0000',
  });

  factory DashboardData.mock() {
    final vagas = <Vaga>[
      const Vaga(
        label: 'A1',
        status: VagaStatus.livre,
        piso: 1,
      ),
      const Vaga(
        label: 'A2',
        status: VagaStatus.ocupado,
        piso: 1,
      ),
      const Vaga(
        label: 'A3',
        status: VagaStatus.livre,
        piso: 1,
      ),
      const Vaga(
        label: 'A4',
        status: VagaStatus.livre,
        pcd: true,
        piso: 1,
      ),
      const Vaga(
        label: 'A5',
        status: VagaStatus.ocupado,
        piso: 1,
      ),
      const Vaga(
        label: 'A6',
        status: VagaStatus.indisponivel,
        piso: 1,
      ),
      const Vaga(
        label: 'A7',
        status: VagaStatus.livre,
        piso: 1,
      ),
      const Vaga(
        label: 'A8',
        status: VagaStatus.ocupado,
        piso: 1,
      ),
      const Vaga(
        label: 'B1',
        status: VagaStatus.livre,
        piso: 2,
      ),
      const Vaga(
        label: 'B2',
        status: VagaStatus.livre,
        piso: 2,
      ),
      const Vaga(
        label: 'B3',
        status: VagaStatus.ocupado,
        piso: 2,
      ),
      const Vaga(
        label: 'B4',
        status: VagaStatus.ocupado,
        pcd: true,
        piso: 2,
      ),
      const Vaga(
        label: 'B5',
        status: VagaStatus.livre,
        piso: 2,
      ),
      const Vaga(
        label: 'B6',
        status: VagaStatus.indisponivel,
        piso: 2,
      ),
    ];

    // Calcula automaticamente os dados das vagas
    final ocupadas = vagas
        .where(
          (vaga) => vaga.status == VagaStatus.ocupado,
        )
        .length;

    final livres = vagas
        .where(
          (vaga) => vaga.status == VagaStatus.livre,
        )
        .length;

    final total = vagas.length;

    final taxa = total == 0
        ? 0.0
        : (ocupadas / total) * 100;

    return DashboardData(
      totalVagas: total,
      livres: livres,
      ocupadas: ocupadas,
      taxaOcupacao: double.parse(
        taxa.toStringAsFixed(1),
      ),

      // Dados do gráfico de barras
      barChartLabels: const [
        'Seg',
        'Ter',
        'Qua',
        'Qui',
        'Sex',
        'Sáb',
        'Dom',
      ],

      barChartData: const [
        32,
        45,
        38,
        52,
        61,
        48,
        35,
      ],

      // Dados do gráfico de linhas
      lineChartLabels: const [
        '08h',
        '10h',
        '12h',
        '14h',
        '16h',
        '18h',
        '20h',
      ],

      lineChartData: const [
        20,
        35,
        48,
        42,
        65,
        72,
        55,
      ],

      vagas: vagas,

      // Usuário fictício
      nomeUsuario: 'Administrador',
      email: 'admin@industrialpark.com',
      telefone: '(19) 99999-9999',
    );
  }
}