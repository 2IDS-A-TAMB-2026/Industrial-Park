enum VagaStatus {
  livre,
  ocupado,
  indisponivel,
}

class Vaga {
  final String label;
  final VagaStatus status;
  final bool pcd;
  final int piso;

  const Vaga({
    required this.label,
    required this.status,
    this.pcd = false,
    this.piso = 1,
  });
}