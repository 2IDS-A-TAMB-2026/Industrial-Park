import 'package:flutter/material.dart';

import 'app_theme.dart';
import 'pages/home_page.dart';

void main() {
  runApp(const IndustrialParkApp());
}

class IndustrialParkApp extends StatefulWidget {
  const IndustrialParkApp({super.key});

  @override
  State<IndustrialParkApp> createState() =>
      _IndustrialParkAppState();
}

class _IndustrialParkAppState
    extends State<IndustrialParkApp> {

  AppThemeMode _themeMode = AppThemeMode.dark;
  double _fontSizeScale = 1.0;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,

      title: 'Industrial Park',

      theme: ThemeData(
        fontFamily: 'Poppins',
        brightness: Brightness.light,
      ),

      darkTheme: ThemeData(
        fontFamily: 'Poppins',
        brightness: Brightness.dark,
      ),

      themeMode: _themeMode == AppThemeMode.light
          ? ThemeMode.light
          : ThemeMode.dark,

      home: HomePage(
        themeMode: _themeMode,
        fontSizeScale: _fontSizeScale,
      ),
    );
  }
}